//UCDB-Universidade Cat?lica dom Bosco
//Versao do java: java 18.0_171
//Nome: Ergon Zamarian Lima  RA: 167776
//DATA: 18/05/2018
//SOFTWARE DE CONVOLUCAO
package convolucao;

import Vision.Menu;


public class Main {

  
    public static void main(String[] args)
    {
       Menu m = new Menu();
       m.setVisible(true);
        
    }
    
}
